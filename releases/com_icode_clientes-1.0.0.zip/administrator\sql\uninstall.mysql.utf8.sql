DROP TABLE IF EXISTS `#__icode_clientes`;
